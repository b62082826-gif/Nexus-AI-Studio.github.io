@echo off
chcp 65001 >nul
echo Installing build tools...
pip install pyinstaller pywebview requests beautifulsoup4
echo.
echo Building WebCloner.exe ...
pyinstaller --noconsole --onefile --clean --name WebCloner --icon icon.ico --add-data "ui;ui" gui_scraper.py
echo.
echo Done. Your app is at: dist\WebCloner.exe
pause
