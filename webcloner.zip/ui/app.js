// UI glue only: all real work happens in gui_scraper.py (exposed as pywebview.api).
(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const els = {
    title: $("title"), dots: $("dots"), size: $("size"), speed: $("speed"),
    url: $("url"), history: $("history"), note: $("note"),
    single: $("btn-single"), template: $("btn-template"),
    open: $("btn-open"), min: $("btn-min"), close: $("btn-close"),
  };

  let savedPath = "";

  // --- dot matrix: only sets per-dot CSS variables, the animation is in style.css ---
  function buildDots() {
    for (let i = 0; i < 72; i++) {
      const d = document.createElement("span");
      d.className = "dot";
      const lows = [0.12, 0.2, 0.35, 0.6, 1, 1];
      d.style.setProperty("--lo", lows[Math.floor(Math.random() * lows.length)]);
      d.style.setProperty("--dur", (2.4 + Math.random() * 3.6).toFixed(2) + "s");
      d.style.setProperty("--delay", (-Math.random() * 6).toFixed(2) + "s");
      els.dots.appendChild(d);
    }
  }

  function setBusy(busy) {
    els.single.disabled = busy;
    els.template.disabled = busy;
    els.dots.classList.toggle("active", busy);
  }

  function setNote(text, kind) {
    els.note.textContent = text;
    els.note.className = "note" + (kind ? " " + kind : "");
  }

  function run(mode) {
    const url = els.url.value.trim();
    if (!url) {
      setNote("กรุณาใส่ลิงก์เว็บก่อน", "err");
      els.url.focus();
      return;
    }
    els.open.classList.add("hidden");
    window.pywebview.api.start(mode, url);
  }

  // --- called from Python via window.evaluate_js ---
  window.ui = {
    started(mode, url) {
      setBusy(true);
      els.title.textContent = mode === "single" ? "กำลังรวมเป็นไฟล์เดียว" : "กำลังดูดทั้งเว็บ";
      setNote(url);
    },
    progress(mb, mbps, items) {
      els.size.textContent = mb.toFixed(1) + " MB";
      els.speed.textContent = "@ " + mbps.toFixed(1) + " Mbps · " + items + " ไฟล์";
    },
    finished(ok, message) {
      setBusy(false);
      if (ok) {
        savedPath = message;
        els.title.textContent = "เสร็จเรียบร้อย";
        setNote("บันทึกไว้ที่ " + message, "ok");
        els.open.classList.remove("hidden");
      } else {
        els.title.textContent = "เกิดข้อผิดพลาด";
        setNote(message, "err");
      }
    },
    history(list) {
      els.history.innerHTML = "";
      list.forEach((u) => {
        const o = document.createElement("option");
        o.value = u;
        els.history.appendChild(o);
      });
    },
  };

  function init() {
    buildDots();
    window.pywebview.api.get_history().then((list) => {
      window.ui.history(list);
      if (list.length) els.url.value = list[0];
    });
  }

  els.single.addEventListener("click", () => run("single"));
  els.template.addEventListener("click", () => run("template"));
  els.url.addEventListener("keydown", (e) => { if (e.key === "Enter") run("single"); });
  els.open.addEventListener("click", () => window.pywebview.api.open_path(savedPath));
  els.min.addEventListener("click", () => window.pywebview.api.minimize());
  els.close.addEventListener("click", () => window.pywebview.api.close());

  window.addEventListener("pywebviewready", init);
})();
