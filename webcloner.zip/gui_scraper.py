# language: Python, file: gui_scraper.py, target: Python 3.x, Windows 11
#
# Python is the main program (scraping, files, progress).
# The window itself is drawn from HTML/CSS in ./ui (index.html, style.css, app.js).
#
#   pip install pywebview requests beautifulsoup4
#   python gui_scraper.py
import base64
import json
import os
import subprocess
import sys
import threading
import time
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

# When packed into an .exe (PyInstaller), the ui folder is unpacked to _MEIPASS,
# while output and history should live next to the .exe itself.
if getattr(sys, "frozen", False):
  BASE_DIR = os.path.dirname(sys.executable)
  UI_DIR = os.path.join(getattr(sys, "_MEIPASS", BASE_DIR), "ui")
else:
  BASE_DIR = os.path.dirname(os.path.abspath(__file__))
  UI_DIR = os.path.join(BASE_DIR, "ui")
OUTPUT_DIR = os.path.join(BASE_DIR, "output")
HISTORY_FILE = os.path.join(BASE_DIR, "url_history.json")
DEFAULT_URL = "https://bot.wexcea.online/"


# ---------- Download stats (bytes / speed) ----------
class Stats:
  def __init__(self):
    self.lock = threading.Lock()
    self.reset()

  def reset(self):
    with self.lock:
      self.bytes = 0
      self.items = 0
      self.start = time.time()
      self.running = False

  def add(self, n):
    with self.lock:
      self.bytes += n
      self.items += 1

  def snapshot(self):
    with self.lock:
      elapsed = max(time.time() - self.start, 0.001)
      mb = self.bytes / (1024 * 1024)
      mbps = (self.bytes * 8 / 1_000_000) / elapsed
      return mb, mbps, self.items


stats = Stats()


def fetch(url, timeout=10):
  res = requests.get(url, timeout=timeout)
  stats.add(len(res.content))
  return res


# ---------- History ----------
def load_history():
  if os.path.exists(HISTORY_FILE):
    try:
      with open(HISTORY_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
        if isinstance(data, list) and data:
          return data
    except Exception:
      pass
  return [DEFAULT_URL]


def save_history(url):
  history = load_history()
  if url in history:
    history.remove(url)
  history.insert(0, url)
  try:
    with open(HISTORY_FILE, "w", encoding="utf-8") as f:
      json.dump(history[:10], f, ensure_ascii=False, indent=2)
  except Exception:
    pass


def ensure_charset(soup):
  if soup.head:
    if not soup.head.find("meta", charset=True):
      soup.head.insert(0, soup.new_tag("meta", charset="utf-8"))
  else:
    head_tag = soup.new_tag("head")
    head_tag.append(soup.new_tag("meta", charset="utf-8"))
    soup.insert(0, head_tag)


# ---------- Mode 1: single bundled HTML ----------
def bundle_single_html(target_url, output_file=None):
  try:
    if output_file is None:
      os.makedirs(OUTPUT_DIR, exist_ok=True)
      output_file = os.path.join(OUTPUT_DIR, "mirrored_page.html")

    res = fetch(target_url, 15)
    res.encoding = res.apparent_encoding
    if res.status_code != 200:
      return False, f"เซิร์ฟเวอร์ตอบกลับสถานะ {res.status_code}"

    soup = BeautifulSoup(res.text, "html.parser")
    ensure_charset(soup)

    for link in soup.find_all("link", rel=True):
      if "stylesheet" in link.get("rel", []):
        href = link.get("href")
        if href:
          try:
            css_res = fetch(urljoin(target_url, href))
            if css_res.status_code == 200:
              style_tag = soup.new_tag("style")
              style_tag.string = css_res.text
              link.replace_with(style_tag)
          except Exception:
            pass

    for script in soup.find_all("script", src=True):
      src = script.get("src")
      if src:
        try:
          js_res = fetch(urljoin(target_url, src))
          if js_res.status_code == 200:
            script.attrs.clear()
            script.string = js_res.text
        except Exception:
          pass

    for img in soup.find_all("img", src=True):
      src = img.get("src")
      if src and not src.startswith("data:"):
        try:
          img_res = fetch(urljoin(target_url, src))
          if img_res.status_code == 200:
            content_type = img_res.headers.get("content-type", "image/png")
            encoded = base64.b64encode(img_res.content).decode("utf-8")
            img["src"] = f"data:{content_type};base64,{encoded}"
        except Exception:
          pass

    with open(output_file, "w", encoding="utf-8") as f:
      f.write(soup.prettify())

    return True, os.path.abspath(output_file)
  except Exception as e:
    return False, str(e)


# ---------- Mode 2: site template folder ----------
def clone_site_template(target_url, output_dir=None, max_pages=15):
  try:
    if output_dir is None:
      output_dir = os.path.join(OUTPUT_DIR, "website_template")

    base_domain = urlparse(target_url).netloc
    visited = set()
    queue = [target_url]
    os.makedirs(output_dir, exist_ok=True)
    downloaded_count = 0

    while queue and downloaded_count < max_pages:
      current_url = queue.pop(0)
      if current_url in visited:
        continue
      visited.add(current_url)

      try:
        res = fetch(current_url, 12)
        res.encoding = res.apparent_encoding
        if res.status_code != 200:
          continue

        soup = BeautifulSoup(res.text, "html.parser")
        ensure_charset(soup)

        for link in soup.find_all("link", rel=True):
          if "stylesheet" in link.get("rel", []):
            href = link.get("href")
            if href:
              try:
                css_res = fetch(urljoin(current_url, href), 5)
                if css_res.status_code == 200:
                  style_tag = soup.new_tag("style")
                  style_tag.string = css_res.text
                  link.replace_with(style_tag)
              except Exception:
                pass

        for script in soup.find_all("script", src=True):
          src = script.get("src")
          if src:
            try:
              js_res = fetch(urljoin(current_url, src), 5)
              if js_res.status_code == 200:
                script.attrs.clear()
                script.string = js_res.text
            except Exception:
              pass

        for a_tag in soup.find_all("a", href=True):
          abs_url = urljoin(current_url, a_tag.get("href"))
          parsed_link = urlparse(abs_url)
          if (
              parsed_link.netloc == base_domain
              and abs_url not in visited
              and not abs_url.endswith(
                  (".png", ".jpg", ".jpeg", ".gif", ".pdf", ".zip", ".css", ".js")
              )
          ):
            queue.append(abs_url)

        path = urlparse(current_url).path.strip("/")
        if not path or path.endswith("/"):
          filename = "index.html"
          file_dir = output_dir
        else:
          if not path.endswith(".html"):
            path += ".html"
          file_dir = os.path.join(output_dir, os.path.dirname(path))
          filename = os.path.basename(path)

        os.makedirs(file_dir, exist_ok=True)
        with open(os.path.join(file_dir, filename), "w", encoding="utf-8") as f:
          f.write(soup.prettify())

        downloaded_count += 1
      except Exception:
        pass

    if downloaded_count == 0:
      return False, "ดูดหน้าเว็บไม่ได้เลย ตรวจสอบลิงก์หรือการเชื่อมต่ออินเทอร์เน็ต"
    return True, os.path.abspath(output_dir)
  except Exception as e:
    return False, str(e)


# ---------- Bridge between Python and the HTML/CSS UI ----------
class Api:
  """Methods here are callable from app.js as pywebview.api.<name>()."""

  def __init__(self):
    self.window = None
    self.busy = False

  # -- calls from the UI --
  def get_history(self):
    return load_history()

  def start(self, mode, url):
    url = (url or "").strip()
    if self.busy:
      return
    if not urlparse(url).scheme:
      url = "https://" + url
    if mode not in ("single", "template"):
      return

    self.busy = True
    save_history(url)
    self._js("ui.history", load_history())
    self._js("ui.started", mode, url)

    stats.reset()
    stats.running = True
    threading.Thread(target=self._work, args=(mode, url), daemon=True).start()
    threading.Thread(target=self._report, daemon=True).start()
    return True

  def open_path(self, path):
    if not path or not os.path.exists(path):
      return
    target = path if os.path.isdir(path) else os.path.dirname(path)
    if sys.platform.startswith("win"):
      if os.path.isfile(path):
        subprocess.Popen(["explorer", "/select,", os.path.normpath(path)])
      else:
        os.startfile(target)  # noqa: S606 (Windows only)
    elif sys.platform == "darwin":
      subprocess.Popen(["open", target])
    else:
      subprocess.Popen(["xdg-open", target])

  def minimize(self):
    if self.window:
      self.window.minimize()

  def close(self):
    if self.window:
      self.window.destroy()

  # -- background work --
  def _work(self, mode, url):
    try:
      if mode == "single":
        ok, msg = bundle_single_html(url)
      else:
        ok, msg = clone_site_template(url)
    except Exception as e:  # last-resort guard so the UI never stays "busy"
      ok, msg = False, str(e)
    stats.running = False
    time.sleep(0.25)  # let the reporter send the final numbers first
    self._js("ui.progress", *stats.snapshot())
    self._js("ui.finished", ok, msg)
    self.busy = False

  def _report(self):
    while stats.running:
      self._js("ui.progress", *stats.snapshot())
      time.sleep(0.2)

  def _js(self, func, *args):
    if not self.window:
      return
    payload = ", ".join(json.dumps(a, ensure_ascii=False) for a in args)
    try:
      self.window.evaluate_js(f"window.{func}({payload})")
    except Exception:
      pass  # window closed while a job was still running


def main():
  import webview  # imported here so the scraping code can be tested without a GUI

  api = Api()
  api.window = webview.create_window(
      "Web Cloner",
      url=os.path.join(UI_DIR, "index.html"),
      js_api=api,
      width=760,
      height=700,
      min_size=(680, 640),
      frameless=True,
      easy_drag=False,  # dragging is limited to .pywebview-drag-region in the HTML
      background_color="#0e0e0f",
  )
  webview.start()


if __name__ == "__main__":
  main()
